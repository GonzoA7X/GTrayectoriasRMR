package com.example.gtrayectoriasrmr.MobileAnarchy;


public interface JoystickClickedListener {
    public void OnClicked();
    public void OnReleased();
}